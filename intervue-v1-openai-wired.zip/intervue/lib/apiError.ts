import { NextResponse } from "next/server";
import { AuthError } from "./auth";

export function handleApiError(err: unknown) {
  if (err instanceof AuthError) {
    return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  }
  // Log full detail server-side only; never send raw provider/internal errors to the client.
  console.error("[API_ERROR]", err);
  const message = err instanceof Error ? err.message : "Something went wrong";
  // Only surface safe, expected validation-style messages; everything else is generic.
  const safe = /not found|already answered|not authenticated|not in progress|does not belong|unsupported file/i.test(message);
  return NextResponse.json({ error: safe ? message : "Something went wrong. Please try again." }, { status: 400 });
}
