import { completeStructured } from "./provider";
import type { CandidateProfileData, InterviewPlan } from "../types";

const SYSTEM = `You are an expert interview designer. Given a target role, candidate experience level,
interview type, and the candidate's profile, select the most relevant competencies to evaluate.

Return ONLY valid JSON matching this shape:
{
  "competencies": [
    { "name": string, "priority": "high" | "medium" | "low", "targetQuestions": number, "evaluationCriteria": string[] }
  ]
}

Rules:
- Choose 4-7 competencies appropriate to the specific role (e.g. Software Engineer needs Project Experience,
  Data Structures, Backend/APIs, System Design; Data Scientist needs Python, Statistics, ML, Experimentation;
  Product Manager needs Product Sense, Strategy, Metrics, Execution).
- Total targetQuestions across all competencies should be between 8 and 15, scaled to the interview duration.
- Prioritize competencies that align with what's actually in the candidate's resume/projects.`;

const ROLE_COMPETENCIES: Record<string, InterviewPlan> = {
  default: {
    competencies: [
      { name: "Project Experience", priority: "high", targetQuestions: 3, evaluationCriteria: ["ownership", "technical decision making", "problem solving", "impact"] },
      { name: "Programming Fundamentals", priority: "high", targetQuestions: 2, evaluationCriteria: ["correctness", "clarity"] },
      { name: "System Design", priority: "medium", targetQuestions: 2, evaluationCriteria: ["scalability", "trade-offs"] },
      { name: "Problem Solving", priority: "medium", targetQuestions: 2, evaluationCriteria: ["approach", "reasoning"] },
      { name: "Behavioral", priority: "low", targetQuestions: 1, evaluationCriteria: ["communication", "collaboration"] },
    ],
  },
};

export async function buildInterviewPlan(params: {
  targetRole: string;
  experienceLevel: string;
  interviewType: string;
  durationMinutes: number;
  profile: CandidateProfileData;
}): Promise<InterviewPlan> {
  const { targetRole, experienceLevel, interviewType, durationMinutes, profile } = params;

  return completeStructured<InterviewPlan>({
    system: SYSTEM,
    user: `TARGET ROLE: ${targetRole}
EXPERIENCE LEVEL: ${experienceLevel}
INTERVIEW TYPE: ${interviewType}
DURATION (minutes): ${durationMinutes}

CANDIDATE PROFILE:
${JSON.stringify(profile, null, 2)}

Generate the interview plan.`,
    maxTokens: 800,
    mockResponse: () => JSON.stringify(ROLE_COMPETENCIES.default),
  });
}
