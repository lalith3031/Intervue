import { completeStructured } from "./provider";
import type { CandidateProfileData, InterviewFeedbackData } from "../types";

interface TranscriptTurn {
  question: string;
  competency: string;
  answer: string;
  analysis: unknown;
}

const SYSTEM = `You are an expert interview coach producing a detailed post-interview report.
Analyze the full transcript (every question, answer, and per-answer analysis) plus the candidate's
profile and target role.

For EVERY question in the transcript, produce specific, non-generic feedback: what was good, what was
missing, technical issues, a role-specific "better answer" tailored to what the candidate actually said,
concrete steps to improve, and one practice task.

Then produce an overall report and 2-5 learning recommendations that convert weaknesses into a concrete
practice plan (concept, why it matters, a practice task, and a goal for the next interview).

Return ONLY valid JSON matching this exact shape:
{
  "overallScore": number (0-100),
  "categories": {
    "technicalKnowledge": number, "communication": number, "problemSolving": number,
    "answerDepth": number, "relevance": number, "clarity": number
  },
  "strengths": string[],
  "weaknesses": string[],
  "questionFeedback": [
    { "question": string, "answer": string, "score": number (0-100), "whatWasGood": string[], "whatWasMissing": string[],
      "technicalIssues": string[], "betterAnswer": string, "howToImprove": string[], "practiceTask": string }
  ],
  "learningRecommendations": [
    { "category": string, "priority": "high" | "medium" | "low", "concept": string, "reason": string,
      "practiceTask": string, "nextInterviewGoal": string }
  ]
}
Do not produce generic advice — every "betterAnswer" must be specific to what the candidate actually said and to the target role.`;

export async function generateFeedback(params: {
  targetRole: string;
  experienceLevel: string;
  profile: CandidateProfileData;
  transcript: TranscriptTurn[];
}): Promise<InterviewFeedbackData> {
  const { targetRole, experienceLevel, profile, transcript } = params;

  return completeStructured<InterviewFeedbackData>({
    system: SYSTEM,
    user: `TARGET ROLE: ${targetRole}
EXPERIENCE LEVEL: ${experienceLevel}

CANDIDATE PROFILE:
${JSON.stringify(profile, null, 2)}

FULL TRANSCRIPT:
${JSON.stringify(transcript, null, 2)}

Generate the complete feedback report.`,
    maxTokens: 4000,
    mockResponse: () => mockFeedback(transcript),
  });
}

function mockFeedback(transcript: TranscriptTurn[]): string {
  const feedback: InterviewFeedbackData = {
    overallScore: 74,
    categories: {
      technicalKnowledge: 76,
      communication: 72,
      problemSolving: 78,
      answerDepth: 65,
      relevance: 80,
      clarity: 74,
    },
    strengths: ["Communicates clearly", "Grounds answers in real project experience"],
    weaknesses: ["Often omits metrics/quantified impact", "Under-explains trade-offs behind technical decisions"],
    questionFeedback: transcript.map((t) => ({
      question: t.question,
      answer: t.answer,
      score: 70,
      whatWasGood: ["Relevant technology choice mentioned"],
      whatWasMissing: ["Quantified impact", "Trade-offs considered"],
      technicalIssues: [],
      betterAnswer: `A stronger answer would name the specific metric moved (e.g. latency, cost) and explain the trade-off considered for "${t.competency}".`,
      howToImprove: ["Practice quantifying impact with real numbers", "Rehearse explaining trade-offs out loud"],
      practiceTask: `Write a 3-sentence STAR-format answer for this ${t.competency} question, including one concrete metric.`,
    })),
    learningRecommendations: [
      {
        category: "Communication",
        priority: "high",
        concept: "Quantifying impact",
        reason: "Multiple answers described what was built but not its measured effect.",
        practiceTask: "For each past project, write down one number that shows its impact.",
        nextInterviewGoal: "Include at least one metric in every project answer.",
      },
    ],
  };
  return JSON.stringify(feedback);
}
