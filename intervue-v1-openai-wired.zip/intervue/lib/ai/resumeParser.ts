import { completeStructured } from "./provider";
import type { CandidateProfileData } from "../types";

const SYSTEM = `You extract structured candidate information from raw resume text.
Return ONLY valid JSON matching this exact shape:
{
  "name": string,
  "summary": string,
  "education": string[],
  "experience": [{ "company": string, "title": string, "duration": string, "responsibilities": string[], "achievements": string[] }],
  "skills": string[],
  "projects": [{ "name": string, "description": string, "technologies": string[], "impact": string[] }],
  "certifications": string[]
}
If a field is not present in the resume, use an empty string or empty array. Do not invent information.`;

function mockProfile(rawText: string): CandidateProfileData {
  // Deterministic, lightweight mock for local dev without an API key.
  return {
    name: "Candidate",
    summary: rawText.slice(0, 160),
    education: ["B.Tech, Computer Science"],
    experience: [],
    skills: ["JavaScript", "React", "Node.js"],
    projects: [
      {
        name: "Sample Project",
        description: "Built an e-commerce application using React, Node.js, PostgreSQL and Redis.",
        technologies: ["React", "Node.js", "PostgreSQL", "Redis"],
        impact: ["Improved page load time"],
      },
    ],
    certifications: [],
  };
}

export async function parseResume(rawText: string): Promise<CandidateProfileData> {
  return completeStructured<CandidateProfileData>({
    system: SYSTEM,
    user: `RESUME TEXT:\n${rawText.slice(0, 12000)}`,
    maxTokens: 1200,
    mockResponse: () => JSON.stringify(mockProfile(rawText)),
  });
}
