import { completeStructured } from "./provider";
import type { AnswerAnalysis, CandidateProfileData } from "../types";

const SYSTEM = `You are an expert interviewer analyzing a candidate's answer. Be rigorous and specific — do not give generic praise.

Identify precisely: correct/incorrect claims, incomplete or vague answers, overly broad answers,
technically incorrect claims, unsupported claims (numbers/results stated with no justification),
missing trade-offs, missing metrics, missing implementation details, strength or weakness of ownership,
communication quality, and problem-solving quality.

Return ONLY valid JSON matching this exact shape:
{
  "overallScore": number (0-10),
  "technicalCorrectness": number (0-10),
  "relevance": number (0-10),
  "depth": number (0-10),
  "clarity": number (0-10),
  "specificity": number (0-10),
  "strengths": string[],
  "missingPoints": string[],
  "technicalIssues": string[],
  "needsFollowUp": boolean,
  "followUpReason": string,
  "recommendedAction": "FOLLOW_UP" | "NEXT_COMPETENCY" | "CHALLENGE"
}

Set needsFollowUp=true and recommendedAction="FOLLOW_UP" when the answer is vague, mentions a
technology/claim without implementation detail, or is missing metrics/trade-offs that a real
interviewer would naturally probe. Set recommendedAction="CHALLENGE" when the candidate makes an
unsupported or questionable technical claim. Otherwise recommendedAction="NEXT_COMPETENCY".`;

export async function analyzeAnswer(params: {
  question: string;
  answer: string;
  competency: string;
  targetRole: string;
  profile: CandidateProfileData;
}): Promise<AnswerAnalysis> {
  const { question, answer, competency, targetRole, profile } = params;

  return completeStructured<AnswerAnalysis>({
    system: SYSTEM,
    user: `TARGET ROLE: ${targetRole}
COMPETENCY: ${competency}

QUESTION: ${question}
CANDIDATE ANSWER: ${answer}

CANDIDATE PROFILE (for context on claimed experience):
${JSON.stringify(profile, null, 2)}

Analyze this answer.`,
    maxTokens: 700,
    mockResponse: () => mockAnalysis(answer),
  });
}

function mockAnalysis(answer: string): string {
  // Very rough heuristic so mock mode still "feels" adaptive: short/vague answers trigger a follow-up.
  const wordCount = answer.trim().split(/\s+/).filter(Boolean).length;
  const vague = wordCount < 25;
  const analysis: AnswerAnalysis = {
    overallScore: vague ? 5 : 7,
    technicalCorrectness: vague ? 5 : 7,
    relevance: 7,
    depth: vague ? 3 : 6,
    clarity: 7,
    specificity: vague ? 3 : 6,
    strengths: vague ? [] : ["Answer references specific technologies"],
    missingPoints: vague ? ["Implementation details", "Trade-offs considered"] : ["Quantified impact/metrics"],
    technicalIssues: [],
    needsFollowUp: vague,
    followUpReason: vague ? "Answer mentions a technology/approach without implementation detail." : "",
    recommendedAction: vague ? "FOLLOW_UP" : "NEXT_COMPETENCY",
  };
  return JSON.stringify(analysis);
}
