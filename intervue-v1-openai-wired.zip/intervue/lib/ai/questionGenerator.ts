import { completeStructured } from "./provider";
import type { CandidateProfileData, Competency, GeneratedQuestion } from "../types";

const SYSTEM = `You are a professional technical interviewer conducting a live interview.
Generate exactly ONE main question for the given competency.

Rules:
- Ask one question only.
- Never repeat a question already asked (see PREVIOUS QUESTIONS).
- Questions must be relevant to the target role and current competency.
- Questions should match the candidate's experience level.
- Prefer grounding the question in something specific from the candidate's resume/projects when relevant to the competency.
- Do not coach the candidate. Do not provide the answer. Maintain a professional, neutral tone.

Return ONLY valid JSON:
{ "question": string, "competency": string, "type": "MAIN", "reason": string }`;

export async function generateMainQuestion(params: {
  targetRole: string;
  experienceLevel: string;
  profile: CandidateProfileData;
  competency: Competency;
  previousQuestions: string[];
}): Promise<GeneratedQuestion> {
  const { targetRole, experienceLevel, profile, competency, previousQuestions } = params;

  return completeStructured<GeneratedQuestion>({
    system: SYSTEM,
    user: `TARGET ROLE: ${targetRole}
EXPERIENCE LEVEL: ${experienceLevel}
CURRENT COMPETENCY: ${competency.name}
EVALUATION CRITERIA: ${competency.evaluationCriteria.join(", ")}

CANDIDATE PROFILE:
${JSON.stringify(profile, null, 2)}

PREVIOUS QUESTIONS ASKED (do not repeat):
${previousQuestions.length ? previousQuestions.map((q) => `- ${q}`).join("\n") : "(none yet - this is the first question)"}

Generate the next main question for this competency.`,
    maxTokens: 400,
    mockResponse: () => mockQuestion(competency, profile, previousQuestions),
  });
}

function mockQuestion(competency: Competency, profile: CandidateProfileData, previousQuestions: string[]): string {
  const project = profile.projects[0];
  const base =
    project && previousQuestions.length === 0
      ? `Tell me about a technically challenging part of "${project.name}".`
      : `Let's move on to ${competency.name}. Walk me through how you'd approach a problem in this area.`;
  return JSON.stringify({
    question: base,
    competency: competency.name,
    type: "MAIN",
    reason: "Grounded in resume project / current competency focus (mock mode).",
  });
}
