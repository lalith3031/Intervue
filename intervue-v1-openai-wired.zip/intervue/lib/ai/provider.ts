// Central LLM access point. All AI services call `complete()` below.
// Never import Anthropic/OpenAI SDKs directly anywhere else in the codebase —
// this keeps the API key server-side-only and swappable via AI_PROVIDER.

import Anthropic from "@anthropic-ai/sdk";
import OpenAI from "openai";

type Provider = "anthropic" | "openai" | "mock";

function getProvider(): Provider {
  const p = (process.env.AI_PROVIDER || "openai").toLowerCase();
  if (p === "anthropic" || p === "openai" || p === "mock") return p;
  return "mock";
}

let anthropicClient: Anthropic | null = null;
let openaiClient: OpenAI | null = null;

function getAnthropic() {
  if (!anthropicClient) {
    if (!process.env.ANTHROPIC_API_KEY) throw new Error("ANTHROPIC_API_KEY is not set");
    anthropicClient = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
  }
  return anthropicClient;
}

function getOpenAI() {
  if (!openaiClient) {
    if (!process.env.OPENAI_API_KEY) throw new Error("OPENAI_API_KEY is not set");
    openaiClient = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  }
  return openaiClient;
}

export interface CompleteOptions {
  system: string;
  user: string;
  maxTokens?: number;
  /** If provided, mock mode returns this instead of calling any real API. */
  mockResponse?: () => string;
}

/**
 * Calls the configured LLM provider and returns raw text.
 * Callers are responsible for parsing/validating JSON out of the text.
 */
export async function complete(opts: CompleteOptions): Promise<string> {
  const provider = getProvider();

  if (provider === "mock") {
    if (!opts.mockResponse) {
      throw new Error("Mock mode active but no mockResponse provided for this call");
    }
    return opts.mockResponse();
  }

  if (provider === "anthropic") {
    const client = getAnthropic();
    const res = await client.messages.create({
      model: process.env.AI_MODEL || "claude-sonnet-4-6",
      max_tokens: opts.maxTokens ?? 1024,
      system: opts.system,
      messages: [{ role: "user", content: opts.user }],
    });
    const block = res.content.find((b) => b.type === "text");
    return block && block.type === "text" ? block.text : "";
  }

  // openai
  const client = getOpenAI();
  const res = await client.chat.completions.create({
    model: process.env.AI_MODEL || "gpt-5.6-luna",
    max_tokens: opts.maxTokens ?? 1024,
    messages: [
      { role: "system", content: opts.system },
      { role: "user", content: opts.user },
    ],
  });
  return res.choices[0]?.message?.content || "";
}

/**
 * Extracts and parses the first JSON object/array found in a model response,
 * tolerating markdown code fences. Throws if nothing parseable is found.
 */
export function parseJson<T>(raw: string): T {
  let text = raw.trim();
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fenced) text = fenced[1].trim();
  const start = text.search(/[{\[]/);
  if (start === -1) throw new Error("No JSON found in model response");
  text = text.slice(start);
  return JSON.parse(text) as T;
}

/**
 * Calls the LLM and parses structured JSON, retrying once on parse failure
 * with an explicit correction instruction. Never lets a bad response crash
 * the caller — throws a typed error the orchestrator can catch and fall back on.
 */
export async function completeStructured<T>(opts: CompleteOptions): Promise<T> {
  const raw = await complete(opts);
  try {
    return parseJson<T>(raw);
  } catch (err) {
    // Retry once with a stricter instruction
    const retryRaw = await complete({
      ...opts,
      user: `${opts.user}\n\nIMPORTANT: Your previous response could not be parsed as JSON. Respond with ONLY valid JSON, no markdown fences, no commentary.`,
    });
    return parseJson<T>(retryRaw);
  }
}
