import { completeStructured } from "./provider";
import type { AnswerAnalysis, GeneratedQuestion } from "../types";

const SYSTEM = `You are a professional interviewer. The candidate's last answer needs a follow-up.
Generate a follow-up question based SPECIFICALLY on what the candidate just said — reference their
actual words/claims. Probe the exact gap identified in the analysis (missing detail, vague claim,
unsupported statement, etc). Never ask a generic or unrelated question.

Example of correct behavior:
Question: "Tell me about a challenging project."
Candidate: "I built an e-commerce application using React, Node.js and Redis."
Good follow-up: "You mentioned Redis. What data were you caching, and how did you handle cache invalidation?"
Bad follow-up: "Tell me about your biggest weakness." (unrelated — never do this)

Return ONLY valid JSON:
{ "question": string, "competency": string, "type": "FOLLOW_UP", "reason": string }`;

export async function generateFollowUp(params: {
  competency: string;
  previousQuestion: string;
  previousAnswer: string;
  analysis: AnswerAnalysis;
}): Promise<GeneratedQuestion> {
  const { competency, previousQuestion, previousAnswer, analysis } = params;

  return completeStructured<GeneratedQuestion>({
    system: SYSTEM,
    user: `COMPETENCY: ${competency}
PREVIOUS QUESTION: ${previousQuestion}
CANDIDATE ANSWER: ${previousAnswer}

ANALYSIS OF THE ANSWER:
${JSON.stringify(analysis, null, 2)}

Generate a follow-up question that probes the specific gap identified above.`,
    maxTokens: 300,
    mockResponse: () => mockFollowUp(competency, previousAnswer, analysis),
  });
}

function mockFollowUp(competency: string, previousAnswer: string, analysis: AnswerAnalysis): string {
  const gap = analysis.missingPoints[0] || "implementation details";
  return JSON.stringify({
    question: `Can you go deeper on ${gap.toLowerCase()} for what you just described?`,
    competency,
    type: "FOLLOW_UP",
    reason: `Probing missing point: ${gap} (mock mode).`,
  });
}
