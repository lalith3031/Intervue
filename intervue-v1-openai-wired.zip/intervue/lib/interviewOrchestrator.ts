import { prisma } from "./db";
import { generateMainQuestion } from "./ai/questionGenerator";
import { analyzeAnswer } from "./ai/answerAnalyzer";
import { generateFollowUp } from "./ai/followUpGenerator";
import { generateFeedback } from "./ai/feedbackGenerator";
import type {
  AnswerResponse,
  CandidateProfileData,
  Competency,
  InterviewPlan,
} from "./types";

// V1 defaults — enforced server-side so the LLM can never create an unbounded interview.
export const MAX_FOLLOWUPS_PER_COMPETENCY = 2;
export const DEFAULT_MAX_QUESTIONS = 15;

function profileFromRow(row: {
  name: string | null;
  summary: string | null;
  educationJson: string;
  experienceJson: string;
  skillsJson: string;
  projectsJson: string;
  certsJson: string;
}): CandidateProfileData {
  return {
    name: row.name || "",
    summary: row.summary || "",
    education: JSON.parse(row.educationJson),
    experience: JSON.parse(row.experienceJson),
    skills: JSON.parse(row.skillsJson),
    projects: JSON.parse(row.projectsJson),
    certifications: JSON.parse(row.certsJson),
  };
}

function nextCompetency(plan: InterviewPlan, covered: string[]): Competency | null {
  return plan.competencies.find((c) => !covered.includes(c.name)) || null;
}

/**
 * Starts an interview: generates and persists the first main question.
 */
export async function startInterview(interviewId: string, userId: string) {
  const interview = await prisma.interview.findFirstOrThrow({
    where: { id: interviewId, userId },
  });
  const profileRow = await prisma.candidateProfile.findUniqueOrThrow({ where: { userId } });
  const profile = profileFromRow(profileRow);
  const plan: InterviewPlan = JSON.parse(interview.planJson || "{}");

  const firstCompetency = nextCompetency(plan, []);
  if (!firstCompetency) throw new Error("Interview plan has no competencies");

  const generated = await generateMainQuestion({
    targetRole: interview.targetRole,
    experienceLevel: interview.experienceLevel,
    profile,
    competency: firstCompetency,
    previousQuestions: [],
  });

  const question = await prisma.interviewQuestion.create({
    data: {
      interviewId: interview.id,
      competency: firstCompetency.name,
      type: "MAIN",
      text: generated.question,
      reason: generated.reason,
      orderIndex: 1,
    },
  });

  await prisma.interview.update({
    where: { id: interview.id },
    data: {
      status: "IN_PROGRESS",
      currentCompetency: firstCompetency.name,
      questionNumber: 1,
      mainQuestionsAsked: 1,
      startedAt: new Date(),
    },
  });

  const totalTarget = plan.competencies.reduce((sum, c) => sum + c.targetQuestions, 0);

  return {
    type: "QUESTION" as const,
    question: { id: question.id, text: question.text, competency: question.competency, type: "MAIN" as const },
    progress: { current: 1, estimatedTotal: Math.min(totalTarget, DEFAULT_MAX_QUESTIONS) },
  };
}

/**
 * Processes a submitted answer: analyzes it, then decides follow-up / next
 * competency / completion, per the state machine in spec section 7.
 */
export async function processAnswer(params: {
  interviewId: string;
  userId: string;
  questionId: string;
  answerText: string;
}): Promise<AnswerResponse> {
  const { interviewId, userId, questionId, answerText } = params;

  const interview = await prisma.interview.findFirstOrThrow({
    where: { id: interviewId, userId },
    include: { questions: { include: { answer: true }, orderBy: { orderIndex: "asc" } } },
  });
  if (interview.status !== "IN_PROGRESS") throw new Error("Interview is not in progress");

  const question = interview.questions.find((q: (typeof interview.questions)[number]) => q.id === questionId);
  if (!question) throw new Error("Question does not belong to this interview");
  if (question.answer) throw new Error("This question has already been answered");

  const profileRow = await prisma.candidateProfile.findUniqueOrThrow({ where: { userId } });
  const profile = profileFromRow(profileRow);
  const plan: InterviewPlan = JSON.parse(interview.planJson || "{}");

  // 1-4: save answer, analyze it, save analysis
  const analysis = await analyzeAnswer({
    question: question.text,
    answer: answerText,
    competency: question.competency,
    targetRole: interview.targetRole,
    profile,
  });

  await prisma.interviewAnswer.create({
    data: { questionId: question.id, text: answerText, analysisJson: JSON.stringify(analysis) },
  });

  const covered: string[] = JSON.parse(interview.competenciesCoveredJson);
  const hardLimitReached = interview.questionNumber >= DEFAULT_MAX_QUESTIONS;

  const shouldFollowUp =
    analysis.needsFollowUp &&
    interview.followUpsForCurrent < MAX_FOLLOWUPS_PER_COMPETENCY &&
    !hardLimitReached;

  if (shouldFollowUp) {
    const followUp = await generateFollowUp({
      competency: question.competency,
      previousQuestion: question.text,
      previousAnswer: answerText,
      analysis,
    });

    const newQuestion = await prisma.interviewQuestion.create({
      data: {
        interviewId: interview.id,
        competency: question.competency,
        type: "FOLLOW_UP",
        text: followUp.question,
        reason: followUp.reason,
        orderIndex: interview.questionNumber + 1,
      },
    });

    await prisma.interview.update({
      where: { id: interview.id },
      data: {
        questionNumber: { increment: 1 },
        followUpsAsked: { increment: 1 },
        followUpsForCurrent: { increment: 1 },
      },
    });

    const totalTarget = plan.competencies.reduce((sum, c) => sum + c.targetQuestions, 0);
    return {
      type: "FOLLOW_UP",
      question: { id: newQuestion.id, text: newQuestion.text, competency: newQuestion.competency, type: "FOLLOW_UP" },
      progress: { current: interview.questionNumber + 1, estimatedTotal: Math.min(totalTarget, DEFAULT_MAX_QUESTIONS) },
    };
  }

  // Competency sufficiently evaluated — move on
  const newCovered = [...new Set([...covered, question.competency])];
  const upcoming = nextCompetency(plan, newCovered);

  if (upcoming && !hardLimitReached) {
    const previousQuestions = interview.questions.map((q: (typeof interview.questions)[number]) => q.text);
    const generated = await generateMainQuestion({
      targetRole: interview.targetRole,
      experienceLevel: interview.experienceLevel,
      profile,
      competency: upcoming,
      previousQuestions,
    });

    const newQuestion = await prisma.interviewQuestion.create({
      data: {
        interviewId: interview.id,
        competency: upcoming.name,
        type: "MAIN",
        text: generated.question,
        reason: generated.reason,
        orderIndex: interview.questionNumber + 1,
      },
    });

    await prisma.interview.update({
      where: { id: interview.id },
      data: {
        currentCompetency: upcoming.name,
        questionNumber: { increment: 1 },
        mainQuestionsAsked: { increment: 1 },
        followUpsForCurrent: 0,
        competenciesCoveredJson: JSON.stringify(newCovered),
      },
    });

    const totalTarget = plan.competencies.reduce((sum, c) => sum + c.targetQuestions, 0);
    return {
      type: "NEXT_QUESTION",
      question: { id: newQuestion.id, text: newQuestion.text, competency: newQuestion.competency, type: "MAIN" },
      progress: { current: interview.questionNumber + 1, estimatedTotal: Math.min(totalTarget, DEFAULT_MAX_QUESTIONS) },
    };
  }

  // No more competencies (or hard limit reached) — complete the interview
  await completeInterviewInternal(interview.id, newCovered);
  return { type: "COMPLETED", interviewId: interview.id };
}

async function completeInterviewInternal(interviewId: string, coveredCompetencies: string[]) {
  await prisma.interview.update({
    where: { id: interviewId },
    data: { status: "COMPLETED", completedAt: new Date(), competenciesCoveredJson: JSON.stringify(coveredCompetencies) },
  });
}

/**
 * Generates and persists the feedback report for a completed interview.
 * Idempotent: if feedback already exists, returns it without calling the LLM again.
 */
export async function ensureFeedback(interviewId: string, userId: string) {
  const existing = await prisma.interviewFeedback.findUnique({ where: { interviewId } });
  if (existing) return existing;

  const interview = await prisma.interview.findFirstOrThrow({
    where: { id: interviewId, userId },
    include: { questions: { include: { answer: true }, orderBy: { orderIndex: "asc" } } },
  });
  const profileRow = await prisma.candidateProfile.findUniqueOrThrow({ where: { userId } });
  const profile = profileFromRow(profileRow);

  const transcript = interview.questions
    .filter((q: (typeof interview.questions)[number]) => q.answer)
    .map((q: (typeof interview.questions)[number]) => ({
      question: q.text,
      competency: q.competency,
      answer: q.answer!.text,
      analysis: JSON.parse(q.answer!.analysisJson),
    }));

  const feedback = await generateFeedback({
    targetRole: interview.targetRole,
    experienceLevel: interview.experienceLevel,
    profile,
    transcript,
  });

  return prisma.interviewFeedback.create({
    data: {
      interviewId: interview.id,
      overallScore: feedback.overallScore,
      categoriesJson: JSON.stringify(feedback.categories),
      strengthsJson: JSON.stringify(feedback.strengths),
      weaknessesJson: JSON.stringify(feedback.weaknesses),
      questionFeedbackJson: JSON.stringify(feedback.questionFeedback),
      learningRecommendationsJson: JSON.stringify(feedback.learningRecommendations),
    },
  });
}
