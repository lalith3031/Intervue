// ===== Candidate Profile =====

export interface ExperienceEntry {
  company: string;
  title: string;
  duration: string;
  responsibilities: string[];
  achievements: string[];
}

export interface ProjectEntry {
  name: string;
  description: string;
  technologies: string[];
  impact: string[];
}

export interface CandidateProfileData {
  name: string;
  summary: string;
  education: string[];
  experience: ExperienceEntry[];
  skills: string[];
  projects: ProjectEntry[];
  certifications: string[];
}

// ===== Interview Plan =====

export interface Competency {
  name: string;
  priority: "high" | "medium" | "low";
  targetQuestions: number;
  evaluationCriteria: string[];
}

export interface InterviewPlan {
  competencies: Competency[];
}

// ===== Question =====

export type QuestionType = "MAIN" | "FOLLOW_UP";

export interface GeneratedQuestion {
  question: string;
  competency: string;
  type: QuestionType;
  reason: string;
}

// ===== Answer Analysis =====

export type RecommendedAction = "FOLLOW_UP" | "NEXT_COMPETENCY" | "CHALLENGE";

export interface AnswerAnalysis {
  overallScore: number;
  technicalCorrectness: number;
  relevance: number;
  depth: number;
  clarity: number;
  specificity: number;
  strengths: string[];
  missingPoints: string[];
  technicalIssues: string[];
  needsFollowUp: boolean;
  followUpReason: string;
  recommendedAction: RecommendedAction;
}

// ===== Interview State =====

export type InterviewStatus = "CREATED" | "IN_PROGRESS" | "COMPLETED";

export interface InterviewProgress {
  current: number;
  estimatedTotal: number;
}

// ===== Feedback =====

export interface QuestionFeedback {
  question: string;
  answer: string;
  score: number;
  whatWasGood: string[];
  whatWasMissing: string[];
  technicalIssues: string[];
  betterAnswer: string;
  howToImprove: string[];
  practiceTask: string;
}

export interface LearningRecommendation {
  category: string;
  priority: "high" | "medium" | "low";
  concept: string;
  reason: string;
  practiceTask: string;
  nextInterviewGoal: string;
}

export interface InterviewFeedbackData {
  overallScore: number;
  categories: {
    technicalKnowledge: number;
    communication: number;
    problemSolving: number;
    answerDepth: number;
    relevance: number;
    clarity: number;
  };
  strengths: string[];
  weaknesses: string[];
  questionFeedback: QuestionFeedback[];
  learningRecommendations: LearningRecommendation[];
}

// ===== API response union for /answer =====

export type AnswerResponse =
  | { type: "FOLLOW_UP" | "NEXT_QUESTION"; question: { id: string; text: string; competency: string; type: QuestionType }; progress: InterviewProgress }
  | { type: "COMPLETED"; interviewId: string };
