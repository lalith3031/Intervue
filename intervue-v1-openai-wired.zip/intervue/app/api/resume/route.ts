import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireUserId } from "@/lib/auth";
import { extractTextFromFile } from "@/lib/resumeExtract";
import { parseResume } from "@/lib/ai/resumeParser";
import { handleApiError } from "@/lib/apiError";

const MAX_BYTES = 10 * 1024 * 1024;
const ACCEPTED_EXTS = ["pdf", "docx"];

export async function POST(req: NextRequest) {
  try {
    const userId = await requireUserId();

    const form = await req.formData();
    const file = form.get("file");
    if (!file || !(file instanceof File)) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 });
    }

    const ext = file.name.split(".").pop()?.toLowerCase() || "";
    if (!ACCEPTED_EXTS.includes(ext)) {
      return NextResponse.json({ error: "Only .pdf and .docx files are supported" }, { status: 400 });
    }
    if (file.size > MAX_BYTES) {
      return NextResponse.json({ error: "File must be under 10 MB" }, { status: 400 });
    }

    const buffer = Buffer.from(await file.arrayBuffer());
    const rawText = await extractTextFromFile(buffer, file.name);

    if (!rawText.trim()) {
      return NextResponse.json({ error: "Could not extract any text from this file" }, { status: 400 });
    }

    await prisma.resume.create({ data: { userId, fileName: file.name, rawText } });

    const parsed = await parseResume(rawText);

    await prisma.candidateProfile.upsert({
      where: { userId },
      create: {
        userId,
        name: parsed.name,
        summary: parsed.summary,
        educationJson: JSON.stringify(parsed.education),
        experienceJson: JSON.stringify(parsed.experience),
        skillsJson: JSON.stringify(parsed.skills),
        projectsJson: JSON.stringify(parsed.projects),
        certsJson: JSON.stringify(parsed.certifications),
      },
      update: {
        name: parsed.name,
        summary: parsed.summary,
        educationJson: JSON.stringify(parsed.education),
        experienceJson: JSON.stringify(parsed.experience),
        skillsJson: JSON.stringify(parsed.skills),
        projectsJson: JSON.stringify(parsed.projects),
        certsJson: JSON.stringify(parsed.certifications),
      },
    });

    return NextResponse.json({ profile: parsed });
  } catch (err) {
    return handleApiError(err);
  }
}
