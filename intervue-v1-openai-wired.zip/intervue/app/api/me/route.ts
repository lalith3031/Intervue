import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getSessionUserId } from "@/lib/auth";
import { handleApiError } from "@/lib/apiError";

export async function GET() {
  try {
    const userId = await getSessionUserId();
    if (!userId) return NextResponse.json({ user: null });

    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: { profile: true, resumes: { orderBy: { createdAt: "desc" }, take: 1 } },
    });
    if (!user) return NextResponse.json({ user: null });

    return NextResponse.json({
      user: { id: user.id, email: user.email },
      hasResume: user.resumes.length > 0,
      hasProfile: !!user.profile,
    });
  } catch (err) {
    return handleApiError(err);
  }
}
