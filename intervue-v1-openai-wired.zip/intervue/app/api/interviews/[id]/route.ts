import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireUserId } from "@/lib/auth";
import { handleApiError } from "@/lib/apiError";
import { DEFAULT_MAX_QUESTIONS } from "@/lib/interviewOrchestrator";
import type { InterviewPlan } from "@/lib/types";

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  try {
    const userId = await requireUserId();
    const interview = await prisma.interview.findFirstOrThrow({
      where: { id: params.id, userId },
      include: { questions: { include: { answer: true }, orderBy: { orderIndex: "asc" } } },
    });

    const plan: InterviewPlan = JSON.parse(interview.planJson || "{}");
    const totalTarget = plan.competencies?.reduce((sum, c) => sum + c.targetQuestions, 0) ?? 0;

    const lastQuestion = interview.questions[interview.questions.length - 1];
    const awaitingAnswer = lastQuestion && !lastQuestion.answer ? lastQuestion : null;

    return NextResponse.json({
      id: interview.id,
      status: interview.status,
      targetRole: interview.targetRole,
      experienceLevel: interview.experienceLevel,
      interviewType: interview.interviewType,
      progress: { current: interview.questionNumber, estimatedTotal: Math.min(totalTarget, DEFAULT_MAX_QUESTIONS) },
      currentQuestion: awaitingAnswer
        ? { id: awaitingAnswer.id, text: awaitingAnswer.text, competency: awaitingAnswer.competency, type: awaitingAnswer.type }
        : null,
      history: interview.questions
        .filter((q: (typeof interview.questions)[number]) => q.answer)
        .map((q: (typeof interview.questions)[number]) => ({
          question: q.text,
          competency: q.competency,
          type: q.type,
          answer: q.answer!.text,
        })),
    });
  } catch (err) {
    return handleApiError(err);
  }
}
