import { NextResponse } from "next/server";
import { requireUserId } from "@/lib/auth";
import { startInterview } from "@/lib/interviewOrchestrator";
import { handleApiError } from "@/lib/apiError";

export async function POST(_req: Request, { params }: { params: { id: string } }) {
  try {
    const userId = await requireUserId();
    const result = await startInterview(params.id, userId);
    return NextResponse.json(result);
  } catch (err) {
    return handleApiError(err);
  }
}
