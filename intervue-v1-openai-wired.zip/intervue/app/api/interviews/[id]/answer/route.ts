import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { requireUserId } from "@/lib/auth";
import { processAnswer } from "@/lib/interviewOrchestrator";
import { handleApiError } from "@/lib/apiError";

const schema = z.object({ questionId: z.string().min(1), answer: z.string().min(1) });

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const userId = await requireUserId();
    const body = schema.parse(await req.json());

    const result = await processAnswer({
      interviewId: params.id,
      userId,
      questionId: body.questionId,
      answerText: body.answer,
    });

    return NextResponse.json(result);
  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json({ error: "Answer cannot be empty" }, { status: 400 });
    }
    return handleApiError(err);
  }
}
