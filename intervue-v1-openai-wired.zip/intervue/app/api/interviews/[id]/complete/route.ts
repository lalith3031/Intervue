import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireUserId } from "@/lib/auth";
import { ensureFeedback } from "@/lib/interviewOrchestrator";
import { handleApiError } from "@/lib/apiError";

export async function POST(_req: Request, { params }: { params: { id: string } }) {
  try {
    const userId = await requireUserId();

    const interview = await prisma.interview.findFirstOrThrow({ where: { id: params.id, userId } });
    if (interview.status !== "COMPLETED") {
      await prisma.interview.update({
        where: { id: interview.id },
        data: { status: "COMPLETED", completedAt: new Date() },
      });
    }

    await ensureFeedback(params.id, userId);
    return NextResponse.json({ interviewId: params.id, status: "COMPLETED" });
  } catch (err) {
    return handleApiError(err);
  }
}
