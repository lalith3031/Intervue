import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireUserId } from "@/lib/auth";
import { ensureFeedback } from "@/lib/interviewOrchestrator";
import { handleApiError } from "@/lib/apiError";

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  try {
    const userId = await requireUserId();
    // Ensure ownership before generating/returning anything.
    await prisma.interview.findFirstOrThrow({ where: { id: params.id, userId } });

    const feedback = await ensureFeedback(params.id, userId);

    return NextResponse.json({
      overallScore: feedback.overallScore,
      categories: JSON.parse(feedback.categoriesJson),
      strengths: JSON.parse(feedback.strengthsJson),
      weaknesses: JSON.parse(feedback.weaknessesJson),
      questionFeedback: JSON.parse(feedback.questionFeedbackJson),
      learningRecommendations: JSON.parse(feedback.learningRecommendationsJson),
    });
  } catch (err) {
    return handleApiError(err);
  }
}
