import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { requireUserId } from "@/lib/auth";
import { buildInterviewPlan } from "@/lib/ai/interviewPlanner";
import { handleApiError } from "@/lib/apiError";

const schema = z.object({
  targetRole: z.string().min(1),
  experienceLevel: z.string().min(1),
  interviewType: z.string().min(1),
  durationMinutes: z.number().int().min(5).max(90).default(30),
});

export async function POST(req: NextRequest) {
  try {
    const userId = await requireUserId();
    const body = schema.parse(await req.json());

    const profileRow = await prisma.candidateProfile.findUnique({ where: { userId } });
    if (!profileRow) {
      return NextResponse.json({ error: "Upload a resume before starting an interview" }, { status: 400 });
    }

    const profile = {
      name: profileRow.name || "",
      summary: profileRow.summary || "",
      education: JSON.parse(profileRow.educationJson),
      experience: JSON.parse(profileRow.experienceJson),
      skills: JSON.parse(profileRow.skillsJson),
      projects: JSON.parse(profileRow.projectsJson),
      certifications: JSON.parse(profileRow.certsJson),
    };

    const plan = await buildInterviewPlan({
      targetRole: body.targetRole,
      experienceLevel: body.experienceLevel,
      interviewType: body.interviewType,
      durationMinutes: body.durationMinutes,
      profile,
    });

    const interview = await prisma.interview.create({
      data: {
        userId,
        targetRole: body.targetRole,
        experienceLevel: body.experienceLevel,
        interviewType: body.interviewType,
        durationMinutes: body.durationMinutes,
        planJson: JSON.stringify(plan),
      },
    });

    return NextResponse.json({ interviewId: interview.id, plan }, { status: 201 });
  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json({ error: "Invalid input" }, { status: 400 });
    }
    return handleApiError(err);
  }
}

export async function GET() {
  try {
    const userId = await requireUserId();
    const interviews = await prisma.interview.findMany({
      where: { userId },
      orderBy: { createdAt: "desc" },
      include: { feedback: true },
    });
    return NextResponse.json({
      interviews: interviews.map((i: (typeof interviews)[number]) => ({
        id: i.id,
        targetRole: i.targetRole,
        status: i.status,
        createdAt: i.createdAt,
        overallScore: i.feedback?.overallScore ?? null,
      })),
    });
  } catch (err) {
    return handleApiError(err);
  }
}
