import { redirect } from "next/navigation";

export default function RoleSelectionPage() {
  redirect("/role_selection.html");
}
