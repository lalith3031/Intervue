"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { apiFetch, ApiError } from "@/src/lib/apiClient";

interface InterviewSummary {
  id: string;
  targetRole: string;
  status: string;
  createdAt: string;
  overallScore: number | null;
}

export default function HomePage() {
  const router = useRouter();
  const [interviews, setInterviews] = useState<InterviewSummary[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    apiFetch<{ interviews: InterviewSummary[] }>("/api/interviews")
      .then((data) => setInterviews(data.interviews))
      .catch(() => {});
  }, []);

  const completed = interviews.filter((i) => i.overallScore !== null);
  const avgScore = completed.length
    ? Math.round(completed.reduce((sum, i) => sum + (i.overallScore || 0), 0) / completed.length)
    : null;

  async function startNewInterview() {
    setError(null);
    const targetRole = sessionStorage.getItem("intervue_target_role");
    const experienceLevel = sessionStorage.getItem("intervue_experience_level");
    if (!targetRole || !experienceLevel) {
      router.push("/role-selection");
      return;
    }
    setLoading(true);
    try {
      const { interviewId } = await apiFetch<{ interviewId: string }>("/api/interviews", {
        method: "POST",
        body: JSON.stringify({
          targetRole,
          experienceLevel,
          interviewType: "Technical",
          durationMinutes: 30,
        }),
      });
      router.push(`/interview/${interviewId}`);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not start interview");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto min-h-screen max-w-3xl px-6 py-16">
      <h1 className="text-[32px] font-extrabold tracking-[-0.03em] text-ink">Welcome back</h1>
      <p className="mt-1 text-sm text-slate-500">Ready for another round?</p>

      <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3">
        <div className="card p-5">
          <p className="text-xs font-medium uppercase tracking-wide text-slate-400">Interviews</p>
          <p className="mt-1 text-2xl font-bold text-ink">{interviews.length}</p>
        </div>
        <div className="card p-5">
          <p className="text-xs font-medium uppercase tracking-wide text-slate-400">Avg. score</p>
          <p className="mt-1 text-2xl font-bold text-ink">{avgScore !== null ? `${avgScore}` : "—"}</p>
        </div>
        <div className="card p-5">
          <p className="text-xs font-medium uppercase tracking-wide text-slate-400">Completed</p>
          <p className="mt-1 text-2xl font-bold text-ink">{completed.length}</p>
        </div>
      </div>

      {error && <p className="mt-4 text-[13px] text-[#e11d48]">{error}</p>}

      <button
        type="button"
        onClick={startNewInterview}
        disabled={loading}
        className="mt-8 h-12 rounded-xl bg-ink px-8 text-[15px] font-semibold text-white transition-all hover:bg-[#1f2330] disabled:opacity-70"
      >
        {loading ? "Setting up your interview…" : "Start New Interview"}
      </button>

      <div className="mt-12">
        <h2 className="text-[15px] font-semibold text-ink">Recent interviews</h2>
        <div className="mt-4 space-y-3">
          {interviews.length === 0 && (
            <p className="text-sm text-slate-500">No interviews yet — start your first one above.</p>
          )}
          {interviews.map((i) => (
            <a
              key={i.id}
              href={i.status === "COMPLETED" ? `/interview/${i.id}/feedback` : `/interview/${i.id}`}
              className="card flex items-center justify-between p-4 transition-colors hover:border-slate-300"
            >
              <div>
                <p className="text-[14.5px] font-semibold text-ink">{i.targetRole}</p>
                <p className="text-xs text-slate-400">{new Date(i.createdAt).toLocaleDateString()} &middot; {i.status}</p>
              </div>
              {i.overallScore !== null && (
                <span className="text-[15px] font-bold text-ink">{i.overallScore}</span>
              )}
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}
