"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { apiFetch, ApiError } from "@/src/lib/apiClient";

interface Question { id: string; text: string; competency: string; type: "MAIN" | "FOLLOW_UP"; }
interface Progress { current: number; estimatedTotal: number; }
interface HistoryTurn { question: string; competency: string; type: string; answer: string; }

type AnswerResponse =
  | { type: "FOLLOW_UP" | "NEXT_QUESTION"; question: Question; progress: Progress }
  | { type: "COMPLETED"; interviewId: string };

export default function InterviewRoomPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const interviewId = params.id;

  const [targetRole, setTargetRole] = useState("");
  const [interviewType, setInterviewType] = useState("");
  const [question, setQuestion] = useState<Question | null>(null);
  const [progress, setProgress] = useState<Progress>({ current: 0, estimatedTotal: 10 });
  const [history, setHistory] = useState<HistoryTurn[]>([]);
  const [answer, setAnswer] = useState("");
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const state = await apiFetch<{
          status: string; targetRole: string; interviewType: string;
          progress: Progress; currentQuestion: Question | null; history: HistoryTurn[];
        }>(`/api/interviews/${interviewId}`);

        setTargetRole(state.targetRole);
        setInterviewType(state.interviewType);
        setHistory(state.history);

        if (state.status === "COMPLETED") {
          router.push(`/interview/${interviewId}/feedback`);
          return;
        }

        if (state.currentQuestion) {
          setQuestion(state.currentQuestion);
          setProgress(state.progress);
        } else {
          const started = await apiFetch<{ question: Question; progress: Progress }>(
            `/api/interviews/${interviewId}/start`,
            { method: "POST" }
          );
          setQuestion(started.question);
          setProgress(started.progress);
        }
      } catch (err) {
        setError(err instanceof ApiError ? err.message : "Could not load interview");
      } finally {
        setLoading(false);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [interviewId]);

  async function handleSubmit() {
    if (!question || !answer.trim()) return;
    setSubmitting(true);
    setError(null);
    try {
      const result = await apiFetch<AnswerResponse>(`/api/interviews/${interviewId}/answer`, {
        method: "POST",
        body: JSON.stringify({ questionId: question.id, answer }),
      });

      setHistory((h) => [...h, { question: question.text, competency: question.competency, type: question.type, answer }]);
      setAnswer("");

      if (result.type === "COMPLETED") {
        await apiFetch(`/api/interviews/${interviewId}/complete`, { method: "POST" });
        router.push(`/interview/${interviewId}/feedback`);
        return;
      }

      setQuestion(result.question);
      setProgress(result.progress);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not submit answer");
    } finally {
      setSubmitting(false);
    }
  }

  if (loading) {
    return <div className="flex min-h-screen items-center justify-center text-sm text-slate-500">Loading interview…</div>;
  }

  return (
    <div className="mx-auto flex min-h-screen max-w-2xl flex-col px-6 py-10">
      <header className="flex items-center justify-between border-b border-slate-100 pb-4">
        <div>
          <p className="text-[13px] font-bold text-ink">Intervue <span className="text-brand">&middot;</span></p>
          <p className="text-xs text-slate-400">{targetRole} &middot; {interviewType}</p>
        </div>
        <div className="text-right">
          <p className="text-xs text-slate-400">
            Question {progress.current} of ~{progress.estimatedTotal}
          </p>
          <button
            type="button"
            onClick={() => router.push("/home")}
            className="text-xs font-medium text-slate-400 underline hover:text-ink"
          >
            Exit
          </button>
        </div>
      </header>

      <div className="mt-6 flex-1 space-y-6 overflow-y-auto">
        {history.map((turn, idx) => (
          <div key={idx} className="space-y-2">
            <div className="flex gap-2">
              <span className="mt-0.5 rounded-full bg-ink px-2 py-0.5 text-[10px] font-semibold uppercase text-white">AI</span>
              <p className="text-[14.5px] text-ink">{turn.question}</p>
            </div>
            <div className="flex gap-2 pl-8">
              <p className="rounded-xl bg-slate-50 px-4 py-2.5 text-[14.5px] text-slate-700">{turn.answer}</p>
            </div>
          </div>
        ))}

        {question && (
          <div className="flex gap-2">
            <span className="mt-0.5 rounded-full bg-ink px-2 py-0.5 text-[10px] font-semibold uppercase text-white">AI</span>
            <div>
              <p className="text-[15px] font-medium text-ink">{question.text}</p>
              <p className="mt-1 text-xs text-slate-400">{question.competency} {question.type === "FOLLOW_UP" && "· follow-up"}</p>
            </div>
          </div>
        )}
      </div>

      {error && <p className="mt-3 text-[13px] text-[#e11d48]">{error}</p>}

      <div className="mt-6 border-t border-slate-100 pt-4">
        <textarea
          value={answer}
          onChange={(e) => setAnswer(e.target.value)}
          placeholder="Type your answer…"
          rows={4}
          disabled={submitting}
          className="focus-ring w-full resize-none rounded-xl border border-slate-200 p-4 text-[14.5px] outline-none"
        />
        <button
          type="button"
          onClick={handleSubmit}
          disabled={submitting || !answer.trim()}
          className="mt-3 h-11 w-full rounded-xl bg-ink text-[14.5px] font-semibold text-white transition-all hover:bg-[#1f2330] disabled:cursor-not-allowed disabled:opacity-40"
        >
          {submitting ? "Thinking…" : "Submit answer"}
        </button>
      </div>
    </div>
  );
}
