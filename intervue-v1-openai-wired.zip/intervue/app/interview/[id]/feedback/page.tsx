"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { apiFetch, ApiError } from "@/src/lib/apiClient";

interface QuestionFeedback {
  question: string; answer: string; score: number;
  whatWasGood: string[]; whatWasMissing: string[]; technicalIssues: string[];
  betterAnswer: string; howToImprove: string[]; practiceTask: string;
}
interface LearningRecommendation {
  category: string; priority: string; concept: string; reason: string;
  practiceTask: string; nextInterviewGoal: string;
}
interface FeedbackData {
  overallScore: number;
  categories: Record<string, number>;
  strengths: string[];
  weaknesses: string[];
  questionFeedback: QuestionFeedback[];
  learningRecommendations: LearningRecommendation[];
}

export default function FeedbackPage() {
  const params = useParams<{ id: string }>();
  const [data, setData] = useState<FeedbackData | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    apiFetch<FeedbackData>(`/api/interviews/${params.id}/feedback`)
      .then(setData)
      .catch((err) => setError(err instanceof ApiError ? err.message : "Could not load feedback"));
  }, [params.id]);

  if (error) return <div className="p-10 text-sm text-[#e11d48]">{error}</div>;
  if (!data) return <div className="flex min-h-screen items-center justify-center text-sm text-slate-500">Generating your report…</div>;

  return (
    <div className="mx-auto min-h-screen max-w-3xl px-6 py-16">
      <p className="text-sm text-slate-500">Interview report</p>
      <div className="mt-2 flex items-baseline gap-3">
        <h1 className="text-[44px] font-extrabold tracking-[-0.03em] text-ink">{data.overallScore}</h1>
        <span className="text-sm text-slate-400">/ 100 overall</span>
      </div>

      <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3">
        {Object.entries(data.categories).map(([key, value]) => (
          <div key={key} className="card p-4">
            <p className="text-xs capitalize text-slate-400">{key.replace(/([A-Z])/g, " $1")}</p>
            <p className="mt-1 text-lg font-bold text-ink">{value}</p>
          </div>
        ))}
      </div>

      <div className="mt-10 grid gap-6 sm:grid-cols-2">
        <div>
          <h2 className="text-[14px] font-semibold text-ink">Strongest areas</h2>
          <ul className="mt-2 space-y-1.5 text-[14px] text-slate-600">
            {data.strengths.map((s, i) => <li key={i}>&bull; {s}</li>)}
          </ul>
        </div>
        <div>
          <h2 className="text-[14px] font-semibold text-ink">Weakest areas</h2>
          <ul className="mt-2 space-y-1.5 text-[14px] text-slate-600">
            {data.weaknesses.map((s, i) => <li key={i}>&bull; {s}</li>)}
          </ul>
        </div>
      </div>

      <h2 className="mt-12 text-[18px] font-bold text-ink">Question-by-question breakdown</h2>
      <div className="mt-4 space-y-4">
        {data.questionFeedback.map((qf, i) => (
          <div key={i} className="card p-5">
            <div className="flex items-start justify-between gap-4">
              <p className="text-[14.5px] font-semibold text-ink">{qf.question}</p>
              <span className="shrink-0 rounded-full bg-slate-100 px-2.5 py-1 text-xs font-bold text-ink">{qf.score}</span>
            </div>
            <p className="mt-2 rounded-lg bg-slate-50 p-3 text-[13.5px] text-slate-600">{qf.answer}</p>

            {qf.whatWasGood.length > 0 && (
              <div className="mt-3">
                <p className="text-xs font-semibold uppercase tracking-wide text-emerald-600">What was good</p>
                <ul className="mt-1 space-y-0.5 text-[13.5px] text-slate-600">
                  {qf.whatWasGood.map((g, j) => <li key={j}>&bull; {g}</li>)}
                </ul>
              </div>
            )}
            {qf.whatWasMissing.length > 0 && (
              <div className="mt-3">
                <p className="text-xs font-semibold uppercase tracking-wide text-amber-600">What was missing</p>
                <ul className="mt-1 space-y-0.5 text-[13.5px] text-slate-600">
                  {qf.whatWasMissing.map((g, j) => <li key={j}>&bull; {g}</li>)}
                </ul>
              </div>
            )}
            <div className="mt-3">
              <p className="text-xs font-semibold uppercase tracking-wide text-ink">Better answer</p>
              <p className="mt-1 text-[13.5px] text-slate-600">{qf.betterAnswer}</p>
            </div>
            <div className="mt-3">
              <p className="text-xs font-semibold uppercase tracking-wide text-ink">Practice task</p>
              <p className="mt-1 text-[13.5px] text-slate-600">{qf.practiceTask}</p>
            </div>
          </div>
        ))}
      </div>

      <h2 className="mt-12 text-[18px] font-bold text-ink">Your improvement plan</h2>
      <div className="mt-4 space-y-3">
        {data.learningRecommendations.map((rec, i) => (
          <div key={i} className="card p-5">
            <div className="flex items-center justify-between">
              <p className="text-[14.5px] font-semibold text-ink">{rec.concept}</p>
              <span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-semibold uppercase text-ink">{rec.priority}</span>
            </div>
            <p className="mt-1 text-[13.5px] text-slate-500">{rec.reason}</p>
            <p className="mt-2 text-[13.5px] text-ink"><span className="font-semibold">Practice: </span>{rec.practiceTask}</p>
            <p className="mt-1 text-[13.5px] text-ink"><span className="font-semibold">Next interview goal: </span>{rec.nextInterviewGoal}</p>
          </div>
        ))}
      </div>

      <a
        href="/home"
        className="mt-12 inline-block h-12 rounded-xl bg-ink px-8 py-3 text-[15px] font-semibold text-white hover:bg-[#1f2330]"
      >
        Back to Home
      </a>
    </div>
  );
}
