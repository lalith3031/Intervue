import { describe, it, expect, beforeAll, beforeEach, afterAll } from "vitest";
import { execSync } from "node:child_process";
import fs from "node:fs";

process.env.AI_PROVIDER = "mock";
process.env.DATABASE_URL = "file:./test.db";
process.env.JWT_SECRET = "test-secret";

// Push schema to a fresh test DB before any test runs.
beforeAll(() => {
  if (fs.existsSync("./test.db")) fs.unlinkSync("./test.db");
  execSync("npx prisma db push --skip-generate", { stdio: "inherit" });
});

afterAll(() => {
  if (fs.existsSync("./test.db")) fs.unlinkSync("./test.db");
});

const { prisma } = await import("../lib/db");
const { startInterview, processAnswer, ensureFeedback, MAX_FOLLOWUPS_PER_COMPETENCY, DEFAULT_MAX_QUESTIONS } =
  await import("../lib/interviewOrchestrator");

async function seedUserWithProfile() {
  const user = await prisma.user.create({
    data: { email: `test-${Date.now()}-${Math.random()}@example.com`, passwordHash: "x" },
  });
  await prisma.candidateProfile.create({
    data: {
      userId: user.id,
      name: "Test Candidate",
      summary: "Software engineer",
      educationJson: JSON.stringify(["B.Tech CS"]),
      experienceJson: JSON.stringify([]),
      skillsJson: JSON.stringify(["React", "Node.js"]),
      projectsJson: JSON.stringify([
        { name: "E-commerce App", description: "Built an e-commerce application using React, Node.js, PostgreSQL and Redis.", technologies: ["React", "Node.js", "PostgreSQL", "Redis"], impact: [] },
      ]),
      certsJson: JSON.stringify([]),
    },
  });
  return user;
}

async function createInterview(userId: string) {
  return prisma.interview.create({
    data: {
      userId,
      targetRole: "Software Engineer",
      experienceLevel: "Mid-level",
      interviewType: "Technical",
      durationMinutes: 30,
      planJson: JSON.stringify({
        competencies: [
          { name: "Project Experience", priority: "high", targetQuestions: 3, evaluationCriteria: ["ownership"] },
          { name: "Databases", priority: "medium", targetQuestions: 2, evaluationCriteria: ["design"] },
        ],
      }),
    },
  });
}

describe("Interview engine core logic", () => {
  it("1. generates a first question", async () => {
    const user = await seedUserWithProfile();
    const interview = await createInterview(user.id);
    const result = await startInterview(interview.id, user.id);
    expect(result.question.text.length).toBeGreaterThan(0);
    expect(result.progress.current).toBe(1);
  });

  it("2. a strong (long, specific) answer moves to the next competency", async () => {
    const user = await seedUserWithProfile();
    const interview = await createInterview(user.id);
    const started = await startInterview(interview.id, user.id);

    const strongAnswer =
      "I designed the caching layer using Redis with a TTL-based invalidation strategy, monitored cache hit rate at 92%, and load-tested it to confirm it reduced p95 latency from 400ms to 90ms under 500 concurrent users.";
    const result = await processAnswer({
      interviewId: interview.id,
      userId: user.id,
      questionId: started.question.id,
      answerText: strongAnswer,
    });
    expect(result.type === "NEXT_QUESTION" || result.type === "COMPLETED").toBe(true);
  });

  it("3. a weak/vague answer triggers a follow-up", async () => {
    const user = await seedUserWithProfile();
    const interview = await createInterview(user.id);
    const started = await startInterview(interview.id, user.id);

    const weakAnswer = "I used Redis to improve application performance.";
    const result = await processAnswer({
      interviewId: interview.id,
      userId: user.id,
      questionId: started.question.id,
      answerText: weakAnswer,
    });
    expect(result.type).toBe("FOLLOW_UP");
  });

  it("4. mandatory acceptance scenario: Redis follow-up chain then topic switch", async () => {
    const user = await seedUserWithProfile();
    const interview = await createInterview(user.id);
    const started = await startInterview(interview.id, user.id);

    // Vague answer -> expect follow-up
    const r1 = await processAnswer({
      interviewId: interview.id, userId: user.id,
      questionId: started.question.id, answerText: "I used Redis to improve application performance.",
    });
    expect(r1.type).toBe("FOLLOW_UP");
    if (r1.type !== "FOLLOW_UP") throw new Error("unreachable");

    // Still vague -> expect a second follow-up (within the 2-follow-up cap)
    const r2 = await processAnswer({
      interviewId: interview.id, userId: user.id,
      questionId: r1.question.id, answerText: "We cached product information.",
    });
    expect(["FOLLOW_UP", "NEXT_QUESTION"]).toContain(r2.type);
  });

  it("5. maximum follow-ups per competency is enforced", async () => {
    const user = await seedUserWithProfile();
    const interview = await createInterview(user.id);
    let current: { question: { id: string; text: string; competency: string; type: string }; progress: { current: number; estimatedTotal: number } } = await startInterview(interview.id, user.id);

    let followUpCount = 0;
    for (let i = 0; i < 5; i++) {
      const result = await processAnswer({
        interviewId: interview.id, userId: user.id,
        questionId: current.question.id, answerText: "short vague answer",
      });
      if (result.type === "FOLLOW_UP" || result.type === "NEXT_QUESTION") {
        if (result.type === "FOLLOW_UP") followUpCount++;
        current = { question: result.question, progress: result.progress };
      } else {
        break;
      }
    }
    expect(followUpCount).toBeLessThanOrEqual(MAX_FOLLOWUPS_PER_COMPETENCY);
  });

  it("6. maximum total questions is enforced and interview completes", async () => {
    const user = await seedUserWithProfile();
    const interview = await createInterview(user.id);
    let current: { question: { id: string; text: string; competency: string; type: string }; progress: { current: number; estimatedTotal: number } } = await startInterview(interview.id, user.id);
    let questionCount = 1;
    let completed = false;

    for (let i = 0; i < DEFAULT_MAX_QUESTIONS + 3; i++) {
      const result = await processAnswer({
        interviewId: interview.id, userId: user.id,
        questionId: current.question.id, answerText: "short vague answer",
      });
      if (result.type === "COMPLETED") { completed = true; break; }
      questionCount++;
      current = { question: result.question, progress: result.progress };
    }
    expect(completed).toBe(true);
    expect(questionCount).toBeLessThanOrEqual(DEFAULT_MAX_QUESTIONS + 1);
  });

  it("7. resume/project context is used in the first question (mock mode)", async () => {
    const user = await seedUserWithProfile();
    const interview = await createInterview(user.id);
    const result = await startInterview(interview.id, user.id);
    expect(result.question.text.toLowerCase()).toContain("e-commerce app".split(" ")[0]);
  });

  it("8. unauthorized access to another user's interview is rejected", async () => {
    const owner = await seedUserWithProfile();
    const intruder = await seedUserWithProfile();
    const interview = await createInterview(owner.id);

    await expect(startInterview(interview.id, intruder.id)).rejects.toThrow();
  });

  it("9. feedback generation is idempotent", async () => {
    const user = await seedUserWithProfile();
    const interview = await createInterview(user.id);
    const started = await startInterview(interview.id, user.id);
    await processAnswer({ interviewId: interview.id, userId: user.id, questionId: started.question.id, answerText: "answer" });

    const f1 = await ensureFeedback(interview.id, user.id);
    const f2 = await ensureFeedback(interview.id, user.id);
    expect(f1.id).toBe(f2.id);
  });
});
