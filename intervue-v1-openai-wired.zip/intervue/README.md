# Intervue — V1

AI interview preparation platform. V1 is text-based: resume → adaptive interview → detailed feedback.

## Architecture

- **Framework:** Next.js 14 (App Router) + TypeScript, single full-stack app.
- **Database:** SQLite via Prisma (swap `DATABASE_URL` to a Postgres URL for production — schema is provider-agnostic).
- **Auth:** email + password (bcrypt), session via signed JWT in an httpOnly cookie. No third-party auth provider — simplest thing that's actually secure.
- **AI:** provider-agnostic — `AI_PROVIDER=anthropic|openai|mock`. Every AI call goes through `lib/ai/provider.ts`; no other file imports an SDK directly, so the API key only ever exists server-side.
- **OpenAI V1 wiring:** the default provider is now `openai`; resume parsing, interview planning, question generation, answer analysis, follow-ups, and final feedback all reach the same server-side OpenAI client when `OPENAI_API_KEY` is configured.
- **Mock mode (`AI_PROVIDER=mock`):** still available for local testing without an API key or cost.

## Files created

```
prisma/schema.prisma          Database schema (see below)
lib/types.ts                  Shared TypeScript types for the whole engine
lib/db.ts                     Prisma client singleton
lib/auth.ts                   Password hashing + JWT session cookie
lib/apiError.ts               Shared API error handling (never leaks raw errors)
lib/resumeExtract.ts          PDF/DOCX -> raw text
lib/interviewOrchestrator.ts  THE STATE MACHINE — start/answer/complete flow
lib/ai/provider.ts            LLM provider abstraction + structured JSON parsing
lib/ai/resumeParser.ts        Raw resume text -> structured CandidateProfile
lib/ai/interviewPlanner.ts    Role + profile -> competency plan
lib/ai/questionGenerator.ts   Generates each MAIN question
lib/ai/answerAnalyzer.ts      Scores + diagnoses every answer
lib/ai/followUpGenerator.ts   Generates contextual follow-ups
lib/ai/feedbackGenerator.ts   Post-interview report + learning recommendations

app/api/auth/signup/route.ts
app/api/auth/login/route.ts
app/api/auth/logout/route.ts
app/api/me/route.ts
app/api/resume/route.ts                        POST — upload + parse resume
app/api/interviews/route.ts                    POST create / GET list
app/api/interviews/[id]/route.ts               GET current state (refresh-safe)
app/api/interviews/[id]/start/route.ts         POST start
app/api/interviews/[id]/answer/route.ts        POST submit answer
app/api/interviews/[id]/complete/route.ts      POST complete
app/api/interviews/[id]/feedback/route.ts      GET feedback report

app/signup/page.tsx            Converted from your landing.html prototype
app/resume/page.tsx            Converted from your resume.html prototype (drag & drop preserved)
app/role-selection/page.tsx    Converted from your role_selection.html prototype
app/home/page.tsx              New — dashboard
app/interview/[id]/page.tsx    New — interview room
app/interview/[id]/feedback/page.tsx  New — feedback report

middleware.ts                  Route protection (redirects unauthenticated users to /signup)
tests/interviewEngine.test.ts  Automated tests, including the mandatory acceptance scenario
```

**Frontend:** the supplied `landing.html`, `resume.html`, and `role_selection.html` are now used as the actual onboarding UI under `public/`, so the animated/reference design is preserved instead of being replaced by a simplified React recreation. The prototype backend seams were wired to the existing V1 API: signup → `/api/auth/signup`, resume upload → `/api/resume`, and role selection → `/api/interviews`. The role screen stores the created interview ID and its “Start your first interview” action opens the real interview room.


## Database schema

`User → Resume, CandidateProfile, Interview → InterviewPlan (JSON) → InterviewQuestion → InterviewAnswer (with AnswerAnalysis JSON), Interview → InterviewFeedback`. Structured AI outputs (profile fields, plan, analysis, feedback) are stored as JSON columns, exactly as the spec allows for V1 — no vector DB, no extra infra.

## How the interview state machine works (`lib/interviewOrchestrator.ts`)

1. `startInterview` — loads the candidate profile + plan, generates the first MAIN question for the first competency.
2. `processAnswer` — on every answer:
   - Saves the answer, runs `analyzeAnswer` (scores + diagnoses it).
   - If `needsFollowUp` is true **and** fewer than 2 follow-ups have been asked for the current competency **and** the 15-question hard cap hasn't been hit → generates a contextual follow-up via `generateFollowUp` (which is given the specific gap from the analysis, so it probes the actual claim — e.g. "You mentioned Redis... how did you handle invalidation?").
   - Otherwise, marks the competency covered and moves to the next one, generating a new MAIN question.
   - If no competencies remain (or the hard cap is hit) → marks the interview `COMPLETED`.
3. All limits (`MAX_FOLLOWUPS_PER_COMPETENCY = 2`, `DEFAULT_MAX_QUESTIONS = 15`) are enforced in this file, server-side — the LLM only ever proposes a question/decision; the backend decides whether it's allowed to happen. This is what stops an infinite interview.

## How feedback works (`ensureFeedback`)

Idempotent — calling it twice returns the same stored report rather than re-billing an LLM call. It sends the full transcript (every question, answer, and per-answer analysis) to `generateFeedback`, which returns per-question breakdowns (good/missing/technical issues/better answer/practice task) plus overall category scores and 2-5 learning recommendations.

## Environment variables

Copy `.env.example` to `.env` and fill in:

```
DATABASE_URL="file:./dev.db"
JWT_SECRET="<long random string>"
AI_PROVIDER="openai"
OPENAI_API_KEY="<your OpenAI API key>"
AI_MODEL="gpt-5.6-luna"
```

`AI_PROVIDER=openai` is the V1 default. Keep the API key server-side in `.env`/`.env.local`; do not put it into any HTML, React client component, or browser environment variable. OpenAI's current JavaScript quickstart likewise uses the official SDK with the key supplied from the server environment.

For a zero-cost local demo, change only `AI_PROVIDER` to `mock`.

## How to run locally

```bash
npm install
npx prisma db push        # creates dev.db with the schema
npm run dev                # http://localhost:3000
```

Open `http://localhost:3000` → sign up → upload a resume (.pdf or .docx) → choose a target role → start the interview. With `AI_PROVIDER=openai`, the server makes the actual model calls. If you see an OpenAI key/model error, verify the `.env` values and restart `npm run dev`.

## How to test

```bash
npm test
```

Runs `tests/interviewEngine.test.ts` against a throwaway SQLite test DB (created/destroyed automatically) with `AI_PROVIDER=mock`. Covers: first-question generation, strong-answer → next-competency, weak-answer → follow-up, the mandatory Redis follow-up-chain acceptance scenario, max-follow-ups enforcement, max-questions enforcement, resume context usage, unauthorized-access rejection, and feedback idempotency.

**Sandbox note:** I built and verified this in a sandboxed environment where `npm run build` compiles and type-checks cleanly end-to-end (`✓ Compiled successfully`), but Prisma's engine binary download (`binaries.prisma.sh`) and Google Fonts were both blocked by that sandbox's network allowlist — neither is a code issue, both will work normally on your machine. Run `npx prisma generate` after `npm install` on your own machine before `npm run dev`/`npm test` if it isn't triggered automatically.

## What's deliberately NOT in V1 (per the spec)

No voice, no avatar, no video/behavioral analysis — the `Interview Engine` (orchestrator + AI services) is fully decoupled from the text UI so V2 (voice) and V3 (avatar) can wrap it later without touching this core.
